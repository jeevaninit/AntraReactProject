import React from 'react'

const Footer = () => {
  return (
    <div>
      <footer>
        <p>copyright@2024 www.ITproSkillSet.com</p>
      </footer>
    </div>
  )
}

export default Footer